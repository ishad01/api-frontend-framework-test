package model;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class Get {

	public static Response getMaps() {
		return null;}
//	RestAssured.baseURI = URL;
//    System.out.println("log to console " + RestAssured.baseURI );
//    
//    Map headers = new HashMap<>();
//    headers.put(API_Token_KEY,API_Token_Value );
//    
//    Response resp = RestAssured.given()
//    		.headers(headers)
//    		.queryParam(string2, string3)
//    		.when().get(URL)
//    		.then().statusCode(200).log().all().and().extract().response();
//   
//    int id = resp.jsonPath().get("data[0].id");
// 	int error_codeVal = resp.jsonPath().get("error_code");
// 	
//    Assert.assertEquals(200, resp.getStatusCode());
//    
//    System.out.println("print id----------------------" + id);
//	
}
