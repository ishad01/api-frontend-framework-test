package stepDefinition;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;

import io.cucumber.gherkin.internal.com.eclipsesource.json.Json;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import utilities.JsonParser;
import io.cucumber.java.en.Then;


public class BackEndTaskSteps {
	
	private String URL = null;
	private String API_Token_KEY = "X-CMC_PRO_API_KEY";
	private String API_Token_Value = "59ea2ce2-baca-4520-82de-bdae47abcf11";
	private Response resp, resp3 = null;
	private String btcId, usdtId, ethId,id;
	
	
	@Given("Cryptocurrency EndPoint {string}")
	public void cryptocurrency_end_point(String string) {
	   URL = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/map";
	   System.out.println("print url ---------- " + URL);
	    
	}

	@Given("reterive API token from Constants")
	public void reterive_api_token_from_constants() {
		// create config manager in helpers package and use it
	    System.out.println(API_Token_KEY);
	    System.out.println(API_Token_Value);
	    
	}

	@When("Trigger GET {string} API for Cryptocurrency {string} with queryParamter and reterive Ids")
	public void trigger_get_api_for_cryptocurrency_with_query_paramter_and_reterive_ids(String string, String string2) {
	    
		Map headers = new HashMap<>();
	    headers.put(API_Token_KEY,API_Token_Value );
	    RestAssured.baseURI= URL;
	    resp = RestAssured.given()
	    		.headers(headers).log().all()
	    		.queryParam("symbol", string2).log().all()
	    		.when().get(URL)
	    		.then().statusCode(200).log().all().and().extract().response();
	    
	    id = resp.jsonPath().getString("data[0].id");

	    System.out.println("test------" + btcId +  usdtId   + ethId);
	}

	@Then("status should be {int}")
	public void status_should_be(Integer int1) {
	    System.out.println("print code--------------" + resp.statusCode());
	    Assert.assertEquals(resp.statusCode(), 200);
	    
	}

	@Then("Trigger GET API {string} for conversion with queryParameter id, amount {string}, convert {string}")
	public void trigger_get_api_for_conversion_with_query_parameter_id_amount_convert(String string, String string2, String string3) {
		
		String conversion_url = string;
		HashMap headers = new HashMap<>();
	    headers.put(API_Token_KEY,API_Token_Value );
	    headers.put("ContentType","application/xml" );
	    headers.putAll(headers);
	    
	    HashMap queryParams = new HashMap<>();
	    queryParams.put("id", id);
	    queryParams.put("amount", string2);
	    queryParams.put("convert", string3);
	    queryParams.putAll(queryParams);
	    
	   resp = RestAssured.given()
	    		.headers(headers)
	    		.queryParams(queryParams)
	    		.when().get(conversion_url)
	    		.then().statusCode(200).log().all().and().extract().response();
	   
	    
	    Assert.assertNotNull(resp);
	    System.out.println("print conv respp1-----------------");
	    
	}

	@Then("Response status should be {int} and reterive {string} in data array")
	public void response_status_should_be_and_reterive_in_data_array(Integer int1, String string) {
	    
		Assert.assertEquals(resp.statusCode(), 200);
		Assert.assertNotNull(resp.jsonPath().get("data.id"));
	}

	@Then("Response should be populated with {string} in data array")
	public void response_should_be_populated_with_in_data_array(String string) {
	    
		Assert.assertNotNull(resp.jsonPath().get("data.name"));
	}

	@Then("Response should be populated with key as connverion to indicator in quote object")
	public void response_should_be_populated_with_key_as_connverion_to_indicator_in_quote_object() {
	   
		Assert.assertNotNull(resp.jsonPath().get("data.quote.BOB"));
	}

	@Then("Response should be populated with converted price {string} inside key object")
	public void response_should_be_populated_with_converted_price_inside_key_object(String string) {
	   
		Assert.assertNotNull(resp.jsonPath().get("data.quote.BOB.price"));
	}

	@Then("Response should be populated with last updated time as {string} inside key object")
	public void response_should_be_populated_with_last_updated_time_as_inside_key_object(String string) {
	   
		Assert.assertNotNull(resp.jsonPath().get("data.quote.BOB.last_updated"));
	}

	@Then("Response should not contain error code other then {string} inside status")
	public void response_should_not_contain_error_code_other_then_inside_status(String string) {
	   
		int error_codeConv = resp.jsonPath().get("status.error_code");
		Assert.assertEquals(error_codeConv, 0);
		
		
	    
	}

	@When("Trigger GET {string} API for Cryptocurrency with queryParamterMap {string} with queryParamterMapValues {string}")
	public void trigger_get_api_for_cryptocurrency_with_query_paramter_map_with_query_paramter_map_values(String string, String string2, String string3) {
	   
		String info_url = "https://pro-api.coinmarketcap.com/v2/cryptocurrency/info";
		Boolean websiteFlag = false;
		HashMap headers = new HashMap<>();
	    headers.put(API_Token_KEY,API_Token_Value );
	    headers.put("ContentType","application/xml" );
	    headers.putAll(headers);
	    
	    HashMap queryParams = new HashMap<>();
	    queryParams.put("id", "1027");
	    queryParams.putAll(queryParams);
	    
	   resp = RestAssured.given()
	    		.headers(headers).log().all()
	    		.queryParams(queryParams).log().all()
	    		.when().get(info_url)
	    		.then().statusCode(200).log().all().and().extract().response();
	   
	    
	    Assert.assertNotNull(resp);
	    System.out.println("print conv info scenerio2-----------------");
	   
	}

	@Then("get technical documentation website from Response")
	public void get_technical_documentation_website_from_response() {
	    
	
		 
		 HashMap<String,String> map = resp.jsonPath().getJsonObject("data.1027.urls"); 
		    Iterator it = map.entrySet().iterator();
		    Boolean websiteFlag = false;
		    while(it.hasNext()) {
		    	
			   Map.Entry pair = (Map.Entry)it.next();
			   System.out.println(pair.getKey() + ":"  + pair.getValue());
			   if(map.containsKey("website")){
				   websiteFlag = true;
			   }
				      else {
				      websiteFlag = false;
			   }
				   
			   }System.out.println(websiteFlag);
			   
			   Assert.assertTrue(websiteFlag);
		   }


	@Then("Response should contains logo  {string}")
	public void response_should_contains_logo(String string) {
	   
		HashMap<String, String> map = resp.jsonPath().getJsonObject("data.1027");
		String logo = map.get("logo");
				
		System.out.println("print---------symbol------" +logo);
		Assert.assertEquals(logo, "https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png");
	}

	@Then("Response should contains technical_doc uri {string}")
	public void response_should_contains_technical_doc_uri(String string) {
	  
	    
		 HashMap<String,String> map = resp.jsonPath().getJsonObject("data.1027.urls"); 
		    Iterator it = map.entrySet().iterator();
		    Boolean technical_docFlag = false;
		    while(it.hasNext()) {
		    	
			   Map.Entry pair = (Map.Entry)it.next();
			   System.out.println(pair.getKey() + ":"  + pair.getValue());
			   if(map.containsKey("technical_doc")){
				   technical_docFlag = true;
			   }
				      else {
				    	  technical_docFlag = false;
			   }
				   
			   }System.out.println(technical_docFlag);
			   
			   Assert.assertTrue(technical_docFlag);
		  }
		
	

	@Then("Response should contain symbol {string}")
	public void response_should_contain_symbol(String string) {
	    
		
		HashMap<String, String> map = resp.jsonPath().getJsonObject("data.1027");
		System.out.println();
		String symbol = map.get("symbol");
				
		System.out.println("print---------symbol------" +symbol);
		Assert.assertEquals(symbol, "ETH");
	
	}

	@Then("Response should contains field {string}")
	public void response_should_contains_field(String string) {
		
	   
		HashMap<String, String> map = resp.jsonPath().getJsonObject("data.1027");
		System.out.println();
		String date_Added = map.get("date_added");
				
		System.out.println("print---------date_added------" +date_Added);
		Assert.assertEquals(date_Added, "2015-08-07T00:00:00.000Z");
		
	}

	@Then("Response should contains platform {string}")
	public void response_should_contains_platform(String string) {
	   
		HashMap<String, String> map = resp.jsonPath().getJsonObject("data.1027");
		System.out.println();
		String platform = map.get("platform");
				
		System.out.println("print---------date_added------" +platform);
		Assert.assertNull(platform);
		
	}

	@Then("currency tags should be {string}")
	public void currency_tags_should_be(String string) {
	   
//		JSONArray jsonArray = (JSONArray) resp.jsonPath().getJsonObject("data.1027.tags");
//		System.out.println("jsonArray:" +jsonArray.getString(0));
//		//JSONObject miniable = (JSONObject) jsonArray.get(0);
//		//System.out.println(miniable);
	
		
		
		 HashMap<String,String> map = resp.jsonPath().getJsonObject("data.1027"); 
		    Iterator it = map.entrySet().iterator();
		    Boolean tags = false;
		    while(it.hasNext()) {
		    	
		    	
			   Map.Entry pair = (Map.Entry)it.next();
			   System.out.println(pair.getKey() + ":"  + pair.getValue());
			   if(map.containsKey("tags")){
				   tags = true;
			   }
				      else {
				    	  tags = false;
			   }
				   
			   }System.out.println(tags);
			   
			   Assert.assertTrue(tags);
    }
	

	@When("When Trigger GET {string} API for Cryptocurrency with queryParamterMap {string} with queryParamterMapValues {string}")
	public void when_trigger_get_api_for_cryptocurrency_with_query_paramter_map_with_query_paramter_map_values(String string, String string2, String string3) {
	   
		String info_url = "https://pro-api.coinmarketcap.com/v2/cryptocurrency/info";
		Boolean websiteFlag = false;
		HashMap headers = new HashMap<>();
	    headers.put(API_Token_KEY,API_Token_Value );
	    headers.put("ContentType","application/xml" );
	    headers.putAll(headers);
	    
	    HashMap queryParams = new HashMap<>();
	    queryParams.put(string2, string3);
	    queryParams.putAll(queryParams);
	    
	    resp3 = RestAssured.given()
	    		.headers(headers).log().all()
	    		.queryParams(queryParams).log().all()
	    		.when().get(info_url)
	    		.then().log().all().extract().response();
	   
	    
	    Assert.assertNotNull(resp3);
	    
	    //String resp3String = resp3.toString();
	    String resp3String = resp3.asString();
	    JSONObject resp3json = new JSONObject(resp3String);
	    //JsonParser.getKey(resp3json, "name");
	    JsonParser.getKey(resp3json, "name");
	   	     
	}
	    

	@Then("Status code should be {string} OK")
	public void status_code_should_be_ok(String string) {
	    
	    Assert.assertEquals(200,resp3.getStatusCode());
	}

	@Then("get currencies with mineable tag")
	public void get_currencies_with_mineable_tag() {
	   
		String resp3String = resp3.asString();
	    JSONObject resp3json = new JSONObject(resp3String);
	    //JsonParser.getKey(resp3json, "name");
	  //  String tags= JsonParser.getKey(resp3json, "tag");
		
	}

	@Then("print currencies with mineable tag")
	public void print_currencies_with_mineable_tag() {
	   
	    
	}
}
