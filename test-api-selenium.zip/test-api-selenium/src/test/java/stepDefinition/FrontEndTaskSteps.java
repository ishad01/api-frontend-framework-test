package stepDefinition;

import static org.junit.Assert.assertTrue;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import helpers.RecordsOutSideLimit;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageObjects.CurrenciesPage;
import pageObjects.HomePage;
import pageObjects.LoginPage;

public class FrontEndTaskSteps {
	
	
	private static WebDriver driver = null ;
	private static List<WebElement> dropdownValues = null;
	HomePage home;
	LoginPage login;
	CurrenciesPage currency;
	String RecordedName,RecordedPrice,Recordedt24h,Recordedt7d,RecordedCap,RecordedVolume = null;
	String InputCurrency = null;
	Actions b = new Actions(driver);
  
	
	@Before("@FrontendTests")
	 public static void setUp(){
	     System.out.println("Hooks - Set up ");

	     try { 	 
	    	 WebDriverManager.chromedriver().setup();
		     driver = new ChromeDriver();
		     driver.manage().window().maximize();
		     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    	 
	     }catch(WebDriverException e) {
	       	 e.printStackTrace();
	       	 
		}   
	 }
	 
	 @After("@FrontendTests")
	    public void tearDown(){
		 if (driver != null) {	 
	         driver.quit();
	     }
	        System.out.println("Hooks- Tear down webdriver");
	    }
	
	
	@Given("Login website {string} with username {string} and password {string}")
	public void open_website_with_username_and_password(String string, String string2, String string3) {

		String url = string;
		String uname = string2;
		String password = string3;
		
	    driver.navigate().to(url);
	    home = new HomePage(driver);
		try {
			
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			Boolean flag = home.isPageOpened();
			
			System.out.println("is it home page------------" + flag);
				Assert.assertTrue(flag);
				
		}catch(TimeoutException e) {
			e.printStackTrace();
		}
		
		LoginPage login = new LoginPage(driver);
		login.ClickOnLandingPageLogin();
		login.InputEmailAddress(uname);
		login.InputPassword(password);
		login.ClickOnLoginButton();
		
		try {
			
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			
			Boolean flag = home.isPageOpened();
			System.out.println("print------------" + flag);
				Assert.assertTrue(flag);
				
		}catch(TimeoutException e) {
			e.printStackTrace();
		}
		

	}

	@When("User click on View All")
	public void user_click_on_view_all() {
		try {
			home.clickOnViewAll();
			home.clickOnFilter();
			//driver.findElement(By.xpath("//div[@class='sc-16r8icm-0 gbNiRM table-control-page-sizer']//div[@class='sc-16r8icm-0 tu1guj-0 hueEpF']")).click();
		    //driver.findElement(By.xpath("//button[normalize-space()='Filters']")).click();
			
		}catch(NoSuchElementException e){
			e.printStackTrace();
		}
	       
	
	}

	@Then("User should able to see results {string}")
	public void user_should_able_to_see_results(String string) {
	    
		String expectedNoOfRows = string;
		//List<WebElement> rows = driver.findElements(By.cssSelector("div[class='tableWrapper___3utdq cmc-table-homepage-wrapper___22rL4'] tr:nth-child(n+2)"));
		
		//int count = rows.size();
		try {
			 int count = home.noOfRowsOnViewAll();
			 System.out.println("no. of rows: "+count);
				Assert.assertEquals(String.valueOf(count),expectedNoOfRows);
				
		}catch(NoSuchElementException e) {
			e.printStackTrace();
		}
		
		
	  
	}
	
	@When("User Select cryptocurrencies {string}")
	public void user_select_cryptocurrencies(String string) throws java.util.concurrent.TimeoutException, InterruptedException {
		
		InputCurrency = string;
		int rowNo = 1;
		home.scrollDown(0, 500);
		System.out.println("scrollin down---------");
		
		rowNo = home.rowNo(string);
		home.clickOnEllipsis(rowNo);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				 ArrayList<WebElement> expectedOptions = (ArrayList<WebElement>) home.EllipsisDisplayOptions();
				 WebDriverWait waitlist = new WebDriverWait(driver,10);
				 waitlist.until(ExpectedConditions.visibilityOfAllElements(expectedOptions));
								
	   home.AddToWatch(rowNo);
	   System.out.println("add to watch is fine");
	   home.checkItOut();
	   System.out.println("Check it out done");
	   
	}
		
		
	
	@When("Add Selected cryptocurrencies to Watch List from ellipsis dropdown")
	public void add_selected_cryptocurrencies_to_watch_list_from_ellipsis_dropdown() {
		
		System.out.println("This option (add to watchList) is not available in 3 dot ellipsis dropdown."
				+ "Here i have added to wishlist from left side star icon on webTable on above step");
	    
	}
	@When("User Click on Watch List using different browser tab")
	public void user_click_on_watch_list_using_different_browser_tab() throws InterruptedException {
	    
	    home.scrollDown(0, -500);
	
		String baseUrl = "https://coinmarketcap.com/";
	    driver.get(baseUrl);
	    ((JavascriptExecutor)driver).executeScript("window.open()");
	    ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
	    driver.switchTo().window(tabs.get(1));
	    driver.get("https://coinmarketcap.com/watchlist/");
	    Thread.sleep(2000);
	    
}

	@Then("cryptocurrencies should be added to watchlist")
	public void cryptocurrencies_should_be_added_to_watchlist() {
	  
		String  currencyAdded = InputCurrency;
	    WebElement table = driver.findElement(By.tagName("table"));
	    List<WebElement> rows = table.findElements(By.cssSelector("tr"));
	    int row = -1;  //to exclude headers
	    for(WebElement r : rows) {
	    	if(r.getText().contains(currencyAdded)) {
	    		
	    		//WebElement myRowElement =  driver.findElement(By.xpath("//p[@font-weight='semibold'][normalize-space()='XRP']"));
	    		String test = "//p[normalize-space()='"+currencyAdded+"']";
				WebElement myRowElement =  driver.findElement(By.xpath(test));
	    		System.out.println("print inc-------------" + row);	
	    	    
	    	    String watchlist = "tbody tr:nth-child("+row+") td:nth-child(1)";
	    	    driver.findElement(By.cssSelector(watchlist));
	    	    System.out.println("print------------watchlist found");
	    	    Assert.assertTrue(true);
	    	}
	    	row++;
	    }
	    
		
	}
	
	
	@When("User clicks on Cryptocurrencies tab")
	public void user_clicks_on_cryptocurrencies_tab() throws InterruptedException {
	    
		
		dropdownValues= HomePage.click_on_fullListOptions("Cryptocurrencies");
		Thread.sleep(1000);
		
		
		
	}
	 
	
	@Then("dropdown should show following items in dropdown {string} of currencies tab")
	public void dropdown_should_show_following_items_in_dropdown_of_currencies_tab(String string) {
	    // Write code here that turns the phrase above into concrete actions
	  
			 String InputOptions= string;
			 String[] expected = InputOptions.split(",");
			 
			 for(WebElement w : dropdownValues) {
				 Boolean flag = false;
				 if(Arrays.asList(expected).contains(InputOptions)) {
					  flag = true;
				 }else {
					  flag = false;
				 }
			 }
				 
		}
	

	@When("User clicks is Options {string}")
	public void user_clicks_is_options(String string) throws InterruptedException {
	  
		HomePage.click_on_fullListOptions(string);
		driver.navigate().back();
		
	}
	
	
	@Then("Verify options home page are visible to user")
	public void verify_options_home_page_are_visible_to_user() {
		Boolean flag = home.isPageOpened();
		System.out.println("print------------" + flag);
			Assert.assertTrue(flag);
	}

	@When("User clicks is on Home Page")
	public void user_clicks_is_on_home_page() {
	    driver.navigate().refresh();
	    
	}

	@When("User records the table data")
	public void user_records_the_table_data() {
		  HomePage.dumpDataFromWebPageBeforeFilter(2, "Name");
		  	  
	}
	

	@When("Click on Apply on option All CypotoCurrency and selects All Cyptocurrencies  {string} from drop down")
	public void click_on_apply_on_option_all_cypoto_currency_and_selects_all_cyptocurrencies_from_drop_down(String string) throws InterruptedException {
	    
		WebElement Filter = home.getFilterWebElements("Filter");
		Filter.click();
		WebElement MenuOfthreeListItems = home.getFilterWebElements("MenuOfthreeListItems");
		home.performClickActionFilters(MenuOfthreeListItems);
		WebElement AllCurrencies = home.getFilterWebElements("AllCurrencies");
		home.performClickActionFilters(AllCurrencies);
		System.out.println("AllCurrencies WebElement-----" + AllCurrencies);
		Thread.sleep(1000);
	
	}

	@When("Apply filter on Price {string}")
	public void apply_filter_on_price(String string) throws InterruptedException {
		//WebElement PriceMain = home.getFilterWebElements("PriceMain");
		Actions b = new Actions(driver);
		//home.performClickActionFilters(PriceMain);	
		//WebElement PriceFilter1000plus = home.getFilterWebElements("PriceFilter1000plus");
		//home.performClickActionFilters(PriceFilter1000plus);
		
		WebElement PriceCapFilter = driver.findElement(By.xpath("//button[normalize-space()='Price']"));
		b.moveToElement(PriceCapFilter).build().perform();
		b.moveToElement(PriceCapFilter).click().build().perform();
		System.out.println("clicked on price cap filter");
		
		Thread.sleep(1000);
		WebElement PriceCap = driver.findElement(By.xpath("//button[normalize-space()='"+string+"']"));
		b.moveToElement(PriceCap).build().perform();
		b.moveToElement(PriceCap).click().build().perform();
		System.out.println("clicked on price cap filter");
		
		Thread.sleep(1000);
		WebElement PriceFilterApply =driver.findElement(By.xpath("//button[normalize-space()='Apply']"));
		b.moveToElement(PriceFilterApply).build().perform();
		b.moveToElement(PriceFilterApply).click().build().perform();
		System.out.println("clicked on price market cap filter apply");
		
		
	
	}

	@Then("User should able to see results in table")
	public void user_should_able_to_see_results_in_table() {
	    

		String Name = home.getDataFromWebPage(2,"Name");
	    System.out.println("Name: " + Name);
//	    WebElement oldData = home.dumpDataFromWebPageBeforeFilter(2, Name);
//	    String name = oldData.getText();
//	    Assert.assertNotNull(name);
		 
	}

	@Then("resulted colunms should not be empty \\(null)")
	public void resulted_colunms_should_not_be_empty_null() {
		 
		String Price = home.getDataFromWebPage(1,"Price");
		Assert.assertNotNull(Price);
	}

	@Then("resulted  Name {string} should be part of recorded result set")
	public void resulted_name_should_be_part_of_recorded_result_set(String string) {
	    // Write code here that turns the phrase above into concrete actions
		 String Name = home.getDataFromWebPage(2,"Name");
 //    	 WebElement oldData = home.dumpDataFromWebPageBeforeFilter(2, Name);
//		 String name = oldData.getText();
//		 Assert.assertEquals(name,Name);
		    
	}

	@Then("resulted Price {string} should be part of recorded result set")
	public void resulted_price_should_be_part_of_recorded_result_set(String string) {
		 
		String Price = home.getDataFromWebPage(2,"Price");
//		 WebElement oldData = home.dumpDataFromWebPageBeforeFilter(2, Price);
//		 String price = oldData.getText();
//		 Assert.assertEquals(price,Price);
	}

	@Then("resulted %Change {string} should be part of recorded result set")
	public void resulted_change_should_be_part_of_recorded_result_set(String string) {
		String Price = home.getDataFromWebPage(2,"Price");
//		 WebElement oldData = home.dumpDataFromWebPageBeforeFilter(2, %Change);
//		 String price = oldData.getText();
//		 Assert.assertEquals(price,Price);
	    
	}

	@Then("resulted Volume {string} should be part of recorded result set")
	public void resulted_volume_should_be_part_of_recorded_result_set(String string) {
		String Volume = home.getDataFromWebPage(2,"Volume");
//		 WebElement oldData = home.dumpDataFromWebPageBeforeFilter(2, Volume);
//		 String price = oldData.getText();
//		 Assert.assertEquals(price,Volume);
	    
	}

	@Then("resulted Circulating Supply {string} should be part of recorded result set")
	public void resulted_circulating_supply_should_be_part_of_recorded_result_set(String string) {
	    
		String Volume = home.getDataFromWebPage(2,"Circulated Supply");
//		 WebElement oldData = home.dumpDataFromWebPageBeforeFilter(2, "Circulated Supply");
//	     String volume = oldData.getText();
//		 Assert.assertEquals(volume,Volume);
	}

	@When("Click on Apply on option All CypotoCurrency and selects All Cyptocurrencies Coins {string} from drop down")
	public void click_on_apply_on_option_all_cypoto_currency_and_selects_all_cyptocurrencies_coins_from_drop_down(String string) throws InterruptedException {
		
		WebElement Filter = home.getFilterWebElements("Filter");
		Filter.click();
		WebElement MenuOfthreeListItems = home.getFilterWebElements("MenuOfthreeListItems");
		home.performClickActionFilters(MenuOfthreeListItems);
		
		WebElement CoinMain = home.getFilterWebElements(string);
		home.performClickActionFilters(CoinMain);

	
	}


	@When("Apply filter on Market Cap {string}")
	public void apply_filter_on_market_cap(String string) throws InterruptedException {
		
		WebElement MarketCapMain = home.getFilterWebElements("MarketCapMain");
		home.performClickActionFilters(MarketCapMain);
		WebElement MarketCapFilter10B = home.getFilterWebElements("MarketCapFilter10B");
		home.performClickActionFilters(MarketCapFilter10B);
		WebElement ApplyButton = home.getFilterWebElements("ApplyButton");
		home.performClickActionFilters(ApplyButton);
	    
	}

	@When("Apply filter on Mineable {string}")
	public void apply_filter_on_mineable(String string) throws InterruptedException {
		
		WebElement minable = driver.findElement(By.cssSelector("div.sc-9s6e2z-0.cCaLyW:nth-child(7) > button"));
		b.moveToElement(minable).build().perform();
		b.moveToElement(minable).click().build().perform();
	    
	}

	@When("Click on Apply on option All CypotoCurrency and selects All Cyptocurrencies Tokens {string} from drop down")
	public void click_on_apply_on_option_all_cypoto_currency_and_selects_all_cyptocurrencies_tokens_from_drop_down(String string) throws InterruptedException {
	    
		WebElement Filter = home.getFilterWebElements("Filter");
		Filter.click();
		WebElement MenuOfthreeListItems = home.getFilterWebElements("MenuOfthreeListItems");
		home.performClickActionFilters(MenuOfthreeListItems);
		
		WebElement TokenMain = home.getFilterWebElements(string);
		home.performClickActionFilters(TokenMain);
	    
	}
	
	
	@When("Apply filter on ChangePer {string}")
	public void apply_filter_on_change_per(String string) throws InterruptedException {
		WebElement ChangeMain = home.getFilterWebElements("ChangeMain");
		home.performClickActionFilters(ChangeMain);
		WebElement ChangeMainFilter50plus = home.getFilterWebElements("ChangeMainFilter50plus");
		home.performClickActionFilters(ChangeMainFilter50plus);
		WebElement ApplyButton = home.getFilterWebElements("ApplyButton");
		home.performClickActionFilters(ApplyButton);

	}

	@Then("User able to click on subList Options {string} of current tab")
	public void user_able_to_click_on_sub_list_options_of_current_tab(String string) throws InterruptedException {
    // Write code here that turns the phrase above into concrete actions
    home.clickOnSublist_CyptoCurrenecies(string);
	}

	
	@Then("User should able to see No Results found")
	public void user_should_able_to_see_no_results_found() {
	    // Write code here that turns the phrase above into concrete actions
		WebElement NoResultFound = driver.findElement(By.xpath("//p[@class='sc-1eb5slv-0 boVMOy empty-title']"));
		String ActualText = NoResultFound.getText();
		String ExpectedText = "No results";
		Assert.assertEquals(ExpectedText,ActualText);
	
	}
}