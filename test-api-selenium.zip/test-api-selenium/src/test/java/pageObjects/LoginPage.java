package pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
WebDriver driver;
	
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="button[class='sc-1ejyco6-0 eQMwpO']")
	private WebElement LandingPageLogin;
	
	@FindBy(css="input[placeholder='Enter your email address']")
	private WebElement EmailAddress;
	
	@FindBy(css="input[placeholder='Enter your password']")
	private WebElement Password;
	
	
	@FindBy(xpath="//button[normalize-space()='Log In']")
	private WebElement LoginButton;
	
	
	public void  ClickOnLandingPageLogin() {
		LandingPageLogin.click();
		driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);
		
	}
	public void InputEmailAddress(String emailAdd) {
		
		EmailAddress.sendKeys(emailAdd);
		
	}
	
	public void InputPassword(String password) {
		Password.sendKeys(password);
		
	}
	
	public void ClickOnLoginButton() {
		
		LoginButton.click();
	}
	
	
	
}
