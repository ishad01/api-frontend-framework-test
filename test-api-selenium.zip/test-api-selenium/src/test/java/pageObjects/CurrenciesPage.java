package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CurrenciesPage {
	
WebDriver driver;
	
	
	public  CurrenciesPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//body/div[@id='__next']/div/div/div/div/div/div/div/span/button[1]")
	private static WebElement AddTowishlistButton;
	
	@FindBy(css="div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > span")
	private WebElement addTowishlistspan;
	
	// @FindBy(xpath="//*[@class='sc-7f3up6-1 dtMKRz is-starred']/button")
	
	@FindBy(xpath="//*[@class='sc-7f3up6-1 dtMKRz']/button/")
	private WebElement addTowishlistspanbutton;
	
	public void ClickOnAddTowishlistButton() throws InterruptedException {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		Actions action = new Actions(driver);
		
		WebElement span = driver.findElement(By.xpath("//body/div[@id='__next']/div/div/div/div/div/div/div/span/span[2]"));
		WebElement button = driver.findElement(By.xpath("//body/div[@id='__next']/div/div/div/div/div/div/div/span/span[2]/button"));
		WebElement span1 = driver.findElement(By.xpath("//h2[@class ='sc-1q9q90x-0 iYFMbU h1___3QSYG']/following-sibling::span"));
		WebElement tryButton1 = driver.findElement(By.xpath("//h2[@class ='sc-1q9q90x-0 iYFMbU h1___3QSYG']/following-sibling::span/button"));
		WebElement span2 = driver.findElement(By.xpath("//h2[@class ='sc-1q9q90x-0 iYFMbU h1___3QSYG']/following-sibling::span/button/span"));
		
		tryButton1.click();
		
		//Actions action1 = new Actions(driver);
		 //action1.click(span2).perform();
		 //tryButton1.click();
		 //Thread.sleep(40);
		 driver.findElement(By.xpath("//button[@class='sc-1ejyco6-0 czBWYA']")).click();
		//button[@class='sc-1ejyco6-0 czBWYA']
		 
		 //action1.clickAndHold(tryButton).build().perform();
		 //action1.doubleClick(tryButton).perform();
		// action1.clickAndHold();
		// action1.click();
		 
		    //you need to release the control from the test
		    //actions.MoveToElement(element).Release();
		//tryButton.click();
		//action.moveToElement(span).perform();
		//button.click();
		//AddTowishlistButton.click();
		//addTowishlistspan.click();
		System.out.println("click on  button");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void ClickOnAddTowishlistButton1() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		addTowishlistspan.click();
		System.out.println("click on  button1");
		try {
			Thread.sleep(60000);
		} catch (InterruptedException w) {
			// TODO Auto-generated catch block
			w.printStackTrace();
		}
	}
		
	}
}	
