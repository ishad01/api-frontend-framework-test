package pageObjects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.text.Document;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.css.DocumentCSS;

import helpers.RecordsOutSideLimit;

public class HomePage {
	
	static WebDriver driver;
	
	
	public  HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="a[class='cmc-logo-link cmc-link']")
	private WebElement DashboardLogoLink;
	
	@FindBy(xpath="//div[@class='sc-16r8icm-0 gbNiRM table-control-page-sizer']//div[@class='sc-16r8icm-0 tu1guj-0 hueEpF']")
	private WebElement ViewAll;
	
	@FindBy(xpath="//button[normalize-space()='Filters']")
	private WebElement Filter;
	
	@FindBys(@FindBy(css="div[class='tableWrapper___3utdq cmc-table-homepage-wrapper___22rL4'] tr:nth-child(n+2)"))
	private List<WebElement> noOfRowsInTable;
	
	@FindBy(xpath="//button[normalize-space()='View Historical Data']")
	private WebElement Ellipsis_Option_HistData;
	
	@FindBy(xpath="//button[normalize-space()='View Charts']")
	private WebElement Ellipsis_Option_ViewCharts;
	
	@FindBy(xpath="//button[normalize-space()='View Markets']")
	private WebElement Ellipsis_Option_ViewMarket;
		
	@FindBy(css="button[class='sc-1ejyco6-0 czBWYA']")
	private WebElement checkItOutButton;
	
	@FindBy(xpath="//ul[@class='sc-1evth2q-1 hpzJjv']")
	private static WebElement headerListElement;
	
	@FindBy(xpath="//span[normalize-space()='Cryptocurrencies']")
	private static WebElement cyptocurrenciesHeader;
	
	@FindBy(xpath="//span[normalize-space()='Exchanges']")
	private static WebElement ExchangesHeader;
	
	@FindBy(xpath="//span[normalize-space()='Watchlist']")
	private static WebElement WatchlistHeader;
	
	@FindBy(xpath="//span[normalize-space()='Products']")
	private static WebElement ProductsHeader;
	
	@FindBy(xpath="//div[@class='sc-16r8icm-0 kXPxnI']//div[1]//a[1]")
	private WebElement xRanking;
	
	@FindBy(xpath="//div[@id='tippy-1']//div[2]//a[1]")
	private WebElement xGlobalChart;

	@FindBy(xpath="//div[@class='xwtbyq-0 iGclcX cmc-header-desktop']//div[3]//a[1]")
	private WebElement xSportlight;
	
	@FindBy(css="div[class='sc-1bmklno-0 eFlJPj'] button[class='sc-1ejyco6-0 bcxPvk cmc-filter-button']")
	private WebElement MenuOfthreeListItems;
	
	@FindBy(css="div[class='sc-16r8icm-0 kXPxnI cmc-options'] div:nth-child(1) button:nth-child(1)")
	private WebElement AllCurrencies;
	
	@FindBy(xpath="//button[normalize-space()='Tokens']")
	private WebElement Tokens;
	
	@FindBy(css="div.sc-9s6e2z-0.cCaLyW:nth-child(7) > button")
	private WebElement Mineable;
	
	@FindBy(xpath="//button[normalize-space()='Market Cap']")
	private WebElement MarketCapMain;
	
	@FindBy(xpath="//button[normalize-space()='> $10B']")
	private WebElement MarketCapFilter10B;
	
	@FindBy(xpath="//button[normalize-space()='Apply']")
	private WebElement ApplyButton;
	
	@FindBy(xpath="//button[normalize-space()='Price']")
	private WebElement PriceMain;
	
	@FindBy(xpath="//button[normalize-space()='$1,000 +']")
	private WebElement PriceFilter1000plus;
	
	@FindBy(xpath="//button[normalize-space()='% Change']")
	private WebElement ChangeMain;
	
	@FindBy(xpath="//button[normalize-space()='+50%']")
	private WebElement ChangeMainFilter50plus;
	
	@FindBy(css="div.sc-16r8icm-0.bMGQIV.cmc-option-container:nth-child(2) > button")
	private WebElement coins;
	
	public boolean isPageOpened(){

		return DashboardLogoLink.isEnabled();
	   }
	
	public void clickOnViewAll(){
		ViewAll.click();
		
	   }
	
	public void clickOnFilter(){
		Filter.click();
		
	   }
	
	public int noOfRowsOnViewAll() {
		
		return noOfRowsInTable.size();
		
	}
	
	public void scrollDown(int x_axis, int y_axis) {	
		JavascriptExecutor js =  (JavascriptExecutor)driver;
	    js.executeScript("window.scrollBy("+x_axis+","+y_axis+")");
	}
	
	public int rowNo(String cryptocurrencies) {
		WebElement table = driver.findElement(By.tagName("table"));
	    List<WebElement> rows = table.findElements(By.cssSelector("tr"));
	    int row = 0;  //to exclude headers
	    for(WebElement r : rows) {
	    	if(r.getText().contains(cryptocurrencies)) {
	    		
	    		System.out.println("print row nth place-------------" + row);
	    		break;
	    		
	    				
	    	}
	    	row++;
	    } return row;
	   
	}
	
	public void  clickOnEllipsis(int rowNo) {
		System.out.println("print -------------" + rowNo);	
		
		//String ellips = "tbody tr:nth-child("+rowNo+") td:nth-child(11)";
		
		//driver.findElement(By.cssSelector("tbody tr:nth-child("+rowNo+") td:nth-child(11)"));
		try {
			
			WebDriverWait wait = new WebDriverWait(driver,5);
			WebElement ellipsis = driver.findElement(By.cssSelector("tbody tr:nth-child("+rowNo+") td:nth-child(11) div:nth-child(1) button:nth-child(1) span:nth-child(1)"));
			TakesScreenshot flag = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("tbody tr:nth-child("+rowNo+") td:nth-child(11) div:nth-child(1) button:nth-child(1) span:nth-child(1)")));
			
			
			if(rowNo <= 10) {
				ellipsis.click();
				System.out.println("print---------clicked ellipses");
			}
			else {
				throw new RecordsOutSideLimit("Selected cryptocurrency should only captured between 5 to 10" 
						+ rowNo);
			}
			
		
		}catch(Exception e) {
			e.getMessage();
		}
		
	}
	
	
	public WebElement AddToWatch(int rowNo) {
	    	    
		
		
		
		
		
		System.out.println("print -------------" + rowNo);
	    	    //String watchlist = "tbody tr:nth-child("+row+") td:nth-child(1)";
	    	 //return driver.findElement(By.cssSelector("tbody tr:nth-child("+rowNo+") td:nth-child(1)"));
			  
		WebDriverWait wait = new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("tbody tr:nth-child("+rowNo+") td:nth-child(1) span:nth-child(1) span:nth-child(1)")));

			  WebElement AddToWatch = driver.findElement(By.cssSelector("tbody tr:nth-child("+rowNo+") td:nth-child(1) span:nth-child(1) span:nth-child(1)"));
			  System.out.println("print----------------addToWatch xpath" + AddToWatch.getText());
			  if(rowNo <= 10 ) {
				  
				   Actions action = new Actions(driver);
				  action.moveToElement(AddToWatch).build().perform();
				  action.moveToElement(AddToWatch).click().build().perform();
			     
					  try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					
					  try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					 // AddToWatch.click();
					  System.out.println("check--------------waiting");
					  try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				  }
			  return AddToWatch;
		 }
	
	
	public void checkItOut() {
		
		try{
			
			driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
			checkItOutButton.click();
			System.out.println("clicked on checkItOut");
		}catch(org.openqa.selenium.TimeoutException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<WebElement> EllipsisDisplayOptions() {
		
		List<WebElement>  optionsList = new ArrayList<WebElement>();
		optionsList.add(0, Ellipsis_Option_ViewCharts);
		optionsList.add(1, Ellipsis_Option_ViewMarket);
		optionsList.add(2, Ellipsis_Option_HistData);
		
		
		optionsList.addAll(optionsList);
		
		return (ArrayList<WebElement>) optionsList;
	}
	
	
	public void clickOnSublist_CyptoCurrenecies(String SubListOption) throws InterruptedException {
		WebElement xSubListOption= getWebElementOfSubListOptions(SubListOption);
		
		if(SubListOption.equalsIgnoreCase("Ranking")) {			
			String rankingXpath = "//div[@class='sc-16r8icm-0 kXPxnI']//div[1]//a[1]";
			clickOnSubListOptions(xSubListOption,rankingXpath);
			
		}else if(SubListOption.equalsIgnoreCase("GlobalCharts")) {
			String globalChartXpath = "//h6[normalize-space()='Global Charts']";
			clickOnSubListOptions(xSubListOption,globalChartXpath);
			
		}else if(SubListOption.equalsIgnoreCase("Spotlight")) {
			String spotlightXpath = "//div[@class='xwtbyq-0 iGclcX cmc-header-desktop']//div[3]//a[1]";
			clickOnSubListOptions(xSubListOption,spotlightXpath);
		}else {
			System.out.println("Invalid sublist input");
		}
		
	}
	
	
	public WebElement getWebElementOfSubListOptions(String SubListOptionName) {
		
		WebElement xSubListOption = null;
		if(SubListOptionName.equalsIgnoreCase("Ranking")) {
			xSubListOption = xRanking;
		}else if(SubListOptionName.equalsIgnoreCase("GlobalCharts")) {
			xSubListOption = xGlobalChart;
		}else if(SubListOptionName.equalsIgnoreCase("Spotlight")) {
			xSubListOption = xSportlight;
		}else {
			System.out.println("Unable to reterive webelement based on input");
		}
		
		return xSubListOption;
	}
	
	
	public static WebElement getWebElementOffullListOptions(String OptionName) {
		
		WebElement xHeaderElement = null;
		if(OptionName.equalsIgnoreCase("cryptocurrencies")) {
			xHeaderElement = cyptocurrenciesHeader;
		}else if(OptionName.equalsIgnoreCase("Watchlist")) {
			xHeaderElement = WatchlistHeader;
		}else if(OptionName.equalsIgnoreCase("Exchanges")) {
			xHeaderElement = ExchangesHeader;
		}else if(OptionName.equalsIgnoreCase("Products")) {
			xHeaderElement = ProductsHeader;
		}else {
			System.out.println("Invalid input");
		}
		
		return xHeaderElement;
	}
	
	public static List<WebElement>  click_on_fullListOptions(String OptionName) throws InterruptedException {
		WebElement xHeaderElement = getWebElementOffullListOptions(OptionName);
		
		List<WebElement> headerListElements=headerListElement.findElements(By.tagName("li"));	
		for (WebElement li : headerListElements) {
		 if (li.getText().equals(OptionName)) {
			
			Actions a= new Actions(driver); 

		   WebElement mainmenu=xHeaderElement;
		   a.moveToElement(mainmenu).build().perform();
		   Thread.sleep(1000);
		   System.out.println("on :" + OptionName);
		 }
	 
		}
		return headerListElements;
	}
	
	
	
	public void clickOnSubListOptions(WebElement xSubListOption, String fullListOptionXpath) throws InterruptedException{
		
		List<WebElement> headerListElements=headerListElement.findElements(By.tagName("li"));
			
		for (WebElement li : headerListElements) {
		 if (li.getText().equals("Cryptocurrencies")) {
			
			Actions a= new Actions(driver); 

		   WebElement mainmenu=cyptocurrenciesHeader;
		   a.moveToElement(mainmenu).build().perform();
		   System.out.println("hover on main options Cryptocurrencies" );
		   
		   try{
   
			   WebElement Sub = xSubListOption;
			   System.out.println("inside try");
			   System.out.println(Sub.getText());
			
			   if(Sub.isDisplayed() && Sub.isEnabled()) {
				   WebDriverWait wait = new WebDriverWait(driver, 10);
				   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(fullListOptionXpath)));
   
				   try {
					   WebElement Sub2 = xSubListOption;
					   a.moveToElement(Sub2).build().perform();
					   //a.moveToElement(Sub2).click().perform();
					  // Sub2.click();
					   
				   }catch(StaleElementReferenceException e){
					   e.getMessage();
					   System.out.println("click succesfull but delay causes issue");			   
					   driver.navigate().back();
					   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(fullListOptionXpath)));
					   WebElement Sub2 = xSubListOption;
					   a.moveToElement(Sub2).build().perform();
				   
				   }
			   }else {
				   System.out.println("Sub is disabled");
			   }
			   
			  
			   }
			      
		   catch(NoSuchElementException e){
			    driver.navigate().refresh();
			   
		   }
		
		   }
		}
		}
		
	
	public String getDataFromWebPage(int rowNo, String ColName) {
		String defaultval = "test";
		String result = defaultval;
		WebElement storedResult= dumpDataFromWebPageBeforeFilter(rowNo, ColName);
	//	String result = storedResult.getText();
		
		return result;
		
	}
	public static WebElement  dumpDataFromWebPageBeforeFilter(int rowNo, String ColName) {
				
				
		
				WebElement tableElement = driver.findElement(By.tagName("table"));
				System.out.println("dumping and getting webTable data");

				ArrayList<HashMap<String, WebElement>> mainTable = new ArrayList<HashMap<String, WebElement>>();
				ArrayList<WebElement> rowElements = (ArrayList<WebElement>) tableElement.findElements(By.xpath(".//tr"));

				ArrayList<String> columnNames = new ArrayList<String>();
				ArrayList<WebElement> headerElements = (ArrayList<WebElement>) rowElements.get(0).findElements(By.xpath(".//th"));
				for (WebElement headerElement: headerElements) {
				  columnNames.add(headerElement.getText());
				}

				for (WebElement rowElement: rowElements) {
				  HashMap<String, WebElement> row = new HashMap<String, WebElement>();
				  
				  int columnIndex = 0;
				  ArrayList<WebElement> cellElements = (ArrayList<WebElement>) rowElement.findElements(By.xpath(".//td"));
				  for (WebElement cellElement: cellElements) {
				    row.put(columnNames.get(columnIndex), cellElement);
				    columnIndex++;
				  }
				  
				  mainTable.add(row);
				}
				WebElement cellRowData = mainTable.get(rowNo).get(ColName);
				return cellRowData;
				
	}
	
	public WebElement getFilterWebElements(String Name) {
		
		WebElement element = null;
		if(Name.equalsIgnoreCase("Filter")) {
			element = Filter;
			
		}else if(Name.equalsIgnoreCase("MenuOfthreeListItems")) {
			element = MenuOfthreeListItems;
		}else if(Name.equalsIgnoreCase("AllCurrencies")) {
			element = AllCurrencies;
		}else if(Name.equalsIgnoreCase("Coins")) {
			element = coins;				
		}else if(Name.equalsIgnoreCase("Tokens")) {
			element = Tokens;
		}else if(Name.equalsIgnoreCase("Mineable")) {
			element = Mineable;
		}else if(Name.equalsIgnoreCase("MarketCapMain")) {
			element = MarketCapMain;
		}else if(Name.equalsIgnoreCase("MarketCapFilter10B")) {
			element = MarketCapFilter10B;
		}else if(Name.equalsIgnoreCase("ApplyButton")) {
			element = ApplyButton;
		}else if(Name.equalsIgnoreCase("PriceFilter1000plus")) {
			element = PriceFilter1000plus;
		}else if(Name.equalsIgnoreCase("PriceMain")) {
			 element = PriceMain;
		}else if(Name.equalsIgnoreCase("ChangeMainFilter50plus")) {
			element = ChangeMainFilter50plus;
		}else if(Name.equalsIgnoreCase("ChangeMain")) {
			 element = ChangeMain;
		}else{
			System.out.println("Added only limited xPath, add xpath and re-run");
		}
		return element;
		
	}
	
	public void performClickActionFilters(WebElement name) throws InterruptedException {
		
		Actions b = new Actions(driver);
		b.moveToElement(name).build().perform();
		b.moveToElement(name).click().perform();
		Thread.sleep(1000);
	}
}

