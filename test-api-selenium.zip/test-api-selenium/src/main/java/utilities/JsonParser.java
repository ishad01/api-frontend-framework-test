package utilities;

import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

public class JsonParser {
	
	
	public static void printKey(JSONObject json, String key) {
		System.out.println(json.get(key));
	}
	public static String getKey(JSONObject json, String key) {
		
		boolean keyExists = json.has(key);  //for inner keys nested objects
		Iterator<?> keys;
		String nextKeys;
		String returnKey = null;
		
		if(!keyExists) {
			keys = json.keys();
			while (keys.hasNext()) {
			 nextKeys=(String) keys.next();
			 try {
				 if(json.get(nextKeys) instanceof JSONObject) {
					 if(!keyExists) {
						 returnKey = getKey(json.getJSONObject(nextKeys), key);
					 }
					 
				 }else if (json.get(nextKeys) instanceof JSONArray){
					  JSONArray jsonarray = json.getJSONArray(nextKeys);
					  for(int i=0; i < jsonarray.length() ;i++) {
						  String jsonarrayString = jsonarray.get(i).toString();
						  JSONObject innerjson = new JSONObject(jsonarrayString);
						  if(keyExists == false) {
							  returnKey = getKey(innerjson, key);
						  }
						  
					  }
					  }
					 
				 }
			 catch(Exception e) {
				 e.printStackTrace();
			 }
				
			}
		}else {    // for outer keys
			printKey(json, key);
		}
		return returnKey;
	}
	
	public static void main(String[] args) {
		String json = "{\r\n"
				+ "    \"status\": {\r\n"
				+ "        \"timestamp\": \"2021-02-19T22:37:30.454Z\",\r\n"
				+ "        \"error_code\": 0,\r\n"
				+ "        \"error_message\": null,\r\n"
				+ "        \"elapsed\": 11,\r\n"
				+ "        \"credit_count\": 1,\r\n"
				+ "        \"notice\": null\r\n"
				+ "    },\r\n"
				+ "    \"data\": {\r\n"
				+ "        \"1027\": {\r\n"
				+ "            \"id\": 1027,\r\n"
				+ "            \"name\": \"Ethereum\",\r\n"
				+ "            \"symbol\": \"ETH\",\r\n"
				+ "            \"category\": \"coin\",\r\n"
				+ "            \"description\": \"Ethereum (ETH) is a cryptocurrency . Users are able to generate ETH through the process of mining. Ethereum has a current supply of 114,740,505.499. The last known price of Ethereum is 1,955.90338067 USD and is up 0.50 over the last 24 hours. It is currently trading on 5972 active market(s) with $26,310,504,980.39 traded over the last 24 hours. More information can be found at https://www.ethereum.org/.\",\r\n"
				+ "            \"slug\": \"ethereum\",\r\n"
				+ "            \"logo\": \"https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png\",\r\n"
				+ "            \"subreddit\": \"ethereum\",\r\n"
				+ "            \"notice\": \"\",\r\n"
				+ "            \"tags\": [\r\n"
				+ "                \"mineable\",\r\n"
				+ "                \"pow\",\r\n"
				+ "                \"smart-contracts\",\r\n"
				+ "                \"coinbase-ventures-portfolio\",\r\n"
				+ "                \"three-arrows-capital-portfolio\",\r\n"
				+ "                \"polychain-capital-portfolio\"\r\n"
				+ "            ],\r\n"
				+ "            \"tag-names\": [\r\n"
				+ "                \"Mineable\",\r\n"
				+ "                \"PoW\",\r\n"
				+ "                \"Smart Contracts\",\r\n"
				+ "                \"Coinbase Ventures Portfolio\",\r\n"
				+ "                \"Three Arrows Capital Portfolio\",\r\n"
				+ "                \"Polychain Capital Portfolio\"\r\n"
				+ "            ],\r\n"
				+ "            \"tag-groups\": [\r\n"
				+ "                \"OTHER\",\r\n"
				+ "                \"CONSENSUS_ALGORITHM\",\r\n"
				+ "                \"PROPERTY\",\r\n"
				+ "                \"PROPERTY\",\r\n"
				+ "                \"PROPERTY\",\r\n"
				+ "                \"PROPERTY\"\r\n"
				+ "            ],\r\n"
				+ "            \"urls\": {\r\n"
				+ "                \"website\": [\r\n"
				+ "                    \"https://www.ethereum.org/\"\r\n"
				+ "                ],\r\n"
				+ "                \"twitter\": [\r\n"
				+ "                    \"https://twitter.com/ethereum\"\r\n"
				+ "                ],\r\n"
				+ "                \"message_board\": [\r\n"
				+ "                    \"https://forum.ethereum.org/\"\r\n"
				+ "                ],\r\n"
				+ "                \"chat\": [\r\n"
				+ "                    \"https://gitter.im/orgs/ethereum/rooms\"\r\n"
				+ "                ],\r\n"
				+ "                \"explorer\": [\r\n"
				+ "                    \"https://etherscan.io/\",\r\n"
				+ "                    \"https://ethplorer.io/\",\r\n"
				+ "                    \"https://blockchair.com/ethereum\",\r\n"
				+ "                    \"https://bscscan.com/token/0x2170ed0880ac9a755fd29b2688956bd959f933f8\",\r\n"
				+ "                    \"https://eth.tokenview.com/en/blocklist\"\r\n"
				+ "                ],\r\n"
				+ "                \"reddit\": [\r\n"
				+ "                    \"https://reddit.com/r/ethereum\"\r\n"
				+ "                ],\r\n"
				+ "                \"technical_doc\": [\r\n"
				+ "                    \"https://github.com/ethereum/wiki/wiki/White-Paper\"\r\n"
				+ "                ],\r\n"
				+ "                \"source_code\": [\r\n"
				+ "                    \"https://github.com/ethereum\"\r\n"
				+ "                ],\r\n"
				+ "                \"announcement\": [\r\n"
				+ "                    \"https://bitcointalk.org/index.php?topic=428589.0\"\r\n"
				+ "                ]\r\n"
				+ "            },\r\n"
				+ "            \"platform\": null,\r\n"
				+ "            \"date_added\": \"2015-08-07T00:00:00.000Z\",\r\n"
				+ "            \"twitter_username\": \"ethereum\",\r\n"
				+ "            \"is_hidden\": 0\r\n"
				+ "        }\r\n"
				+ "    }\r\n"
				+ "}";
			JSONObject inputjson = new JSONObject(json);
			getKey(inputjson, "tags");
	}

}
		
		
		
