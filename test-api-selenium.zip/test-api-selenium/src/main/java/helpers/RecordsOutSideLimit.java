package helpers;

public class RecordsOutSideLimit extends Exception {
	
   public RecordsOutSideLimit(String message) {
	   super(message);
	   
   }

}
